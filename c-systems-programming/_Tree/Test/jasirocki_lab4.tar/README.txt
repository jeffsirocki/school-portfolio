 Jeff Sirocki - jasirocki
 CS 2303 - A02
 Lab4 - 9/25/14

 jasirocki_lab3.tar includes:
                    - lab4.c
                    - lab4.h
                    - tree.c
                    - Makefile
                    - binarytree.txt (output)
                    - main  (excecutable)
                    - README.txt

Program is fully functional and programmed in C. The program reads in one command line argument num (num of inputs) and the lines of input from a script file lab4.dat. Each time an input is entered it is added to tree. Following the final input, the tree is output INORDER by student id.

 Compile with make command:

    $ make

 To run program, run the executable with command line arg num and
    input script file lab3.dat:

    $ ./lab3 num < lab4.dat

 The output for the following command is in binarytree.txt.
